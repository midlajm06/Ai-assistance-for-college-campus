# College Campus AI Assistant (Flask)

A starter web app that answers common college-campus questions through a chat interface. It currently uses a small rule-based FAQ assistant, so it runs locally without an API key.

## Features
- Flask backend with a JSON chat endpoint
- Responsive chat UI
- Starter answers for library, admissions, fees, exams, hostel, canteen, Wi-Fi, placements, scholarships, attendance, and transport
- Easy-to-edit FAQ logic in `assistant.py`
- Virtual-environment setup scripts for Windows and macOS/Linux

## Requirements
- Python 3.10 or newer
- `pip`

## 1. Create and activate a virtual environment

### Windows (Command Prompt)
```bat
python -m venv .venv
.venv\\Scripts\\activate
```

### Windows (PowerShell)
```powershell
python -m venv .venv
.venv\\Scripts\\Activate.ps1
```

### macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
```

Or run `setup_venv.bat` on Windows, or `bash setup_venv.sh` on macOS/Linux.

## 2. Install dependencies
```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 3. Start the app
```bash
python app.py
```
Open http://127.0.0.1:5000 in your browser. Stop the server with `Ctrl+C`.

## Project structure
```text
college_campus_ai_assistant/
├── app.py
├── assistant.py
├── requirements.txt
├── templates/
│   └── index.html
├── static/
│   ├── style.css
│   └── app.js
├── .env.example
├── .gitignore
├── setup_venv.bat
└── setup_venv.sh
```

## Customize the answers
Edit `FAQ` in `assistant.py`. Each entry contains a set of keywords and an answer. Replace generic guidance with your institution's verified contacts, opening hours, and policies before sharing this app with students.

## Notes
- This is a starter project, not connected to live college databases.
- Do not enter passwords, student IDs, payment details, or other sensitive information into the chat.
- `debug=True` is for local development only. Turn debug mode off before deployment.
