"""Simple rule-based campus assistant. Replace/extend this with an LLM or campus API later."""
import re

FAQ = [
    (("library", "books", "reading room"), "The campus library is usually open Monday–Saturday, 8:00 AM–8:00 PM. Check the library notice board for holiday changes."),
    (("admission", "apply", "application"), "For admissions, check the college admissions portal or contact the admissions office. Keep your application number handy when asking for an update."),
    (("fee", "fees", "tuition", "payment"), "For fee amounts, due dates, receipts, or payment issues, contact the accounts office or check the student portal."),
    (("exam", "examination", "timetable", "schedule"), "Exam timetables are published by the examination cell. Check the student portal and department notice board for the latest version."),
    (("hostel", "dorm", "accommodation"), "For hostel availability, room allocation, and rules, contact the hostel warden or student affairs office."),
    (("canteen", "cafeteria", "food"), "The campus canteen serves meals and snacks during college hours. For today's menu or timings, check the canteen notice board."),
    (("wifi", "internet", "network"), "For campus Wi-Fi, connect using your student credentials. If you cannot sign in, contact the IT help desk; never share your password in chat."),
    (("placement", "career", "internship", "job"), "The placement and career development cell can help with internship notices, eligibility, resume workshops, and recruitment schedules."),
    (("scholarship", "financial aid"), "Ask the scholarship/financial-aid office about eligibility, required documents, deadlines, and application status."),
    (("attendance", "absent", "leave"), "Attendance policies vary by department. Contact your class advisor or department office for your current attendance record and leave process."),
    (("transport", "bus", "shuttle"), "For campus bus routes and timings, check the transport office notice board or student portal."),
    (("contact", "office", "phone", "email"), "You can find official department contacts in the college directory or student portal. If you tell me which office you need, I can suggest the right place to start."),
]

def get_response(message: str) -> str:
    text = re.sub(r"\s+", " ", message.lower()).strip()
    if any(word in text for word in ("hello", "hi", "hey", "good morning", "good afternoon")):
        return "Hi! 👋 I'm your Campus AI Assistant. Ask me about the library, exams, fees, hostel, Wi-Fi, placements, transport, or other campus services."
    if any(word in text for word in ("thank", "thanks", "thx")):
        return "You're welcome! 😊 Anything else about campus I can help with?"
    if any(word in text for word in ("who are you", "what can you do", "help")):
        return "I'm a campus information assistant. I can point you toward common services and explain where to find official information. I may not know live updates, so verify dates, fees, and policies with your college."
    for keywords, answer in FAQ:
        if any(keyword in text for keyword in keywords):
            return answer
    return ("I don't have a verified answer for that yet. Try asking about the library, admissions, fees, exams, hostel, canteen, Wi-Fi, placements, scholarships, attendance, or transport. "
            "For urgent or official matters, please contact your college office.")
