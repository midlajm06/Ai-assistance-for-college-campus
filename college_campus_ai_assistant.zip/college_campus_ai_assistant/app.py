from flask import Flask, render_template, request, jsonify
from assistant import get_response

app = Flask(__name__)

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/api/chat")
def chat():
    payload = request.get_json(silent=True) or {}
    message = str(payload.get("message", "")).strip()
    if not message:
        return jsonify({"reply": "Please type a question so I can help."}), 400
    return jsonify({"reply": get_response(message)})

if __name__ == "__main__":
    app.run(debug=True)
