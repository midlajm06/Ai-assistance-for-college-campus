const form = document.getElementById("chat-form");
const input = document.getElementById("message-input");
const messages = document.getElementById("messages");

function addMessage(text, who) {
  const row = document.createElement("div");
  row.className = `message-row ${who === "user" ? "user" : ""}`;
  if (who === "assistant") {
    const avatar = document.createElement("div");
    avatar.className = "assistant-avatar small";
    avatar.textContent = "✦";
    row.appendChild(avatar);
  }
  const wrap = document.createElement("div");
  wrap.className = "bubble-wrap";
  const sender = document.createElement("span");
  sender.className = "sender";
  sender.textContent = who === "user" ? "YOU" : "CAMPUS ASSISTANT";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  wrap.append(sender, bubble);
  row.appendChild(wrap);
  messages.appendChild(row);
  messages.scrollTop = messages.scrollHeight;
}

async function sendMessage(message) {
  const clean = message.trim();
  if (!clean) return;
  addMessage(clean, "user");
  input.value = "";
  input.disabled = true;
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: clean })
    });
    const data = await response.json();
    addMessage(data.reply || "Sorry, I couldn't process that. Please try again.", "assistant");
  } catch (error) {
    addMessage("I couldn't connect to the server. Please check that the Flask app is running and try again.", "assistant");
  } finally {
    input.disabled = false;
    input.focus();
  }
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  sendMessage(input.value);
});

document.querySelectorAll("[data-prompt]").forEach((button) => {
  button.addEventListener("click", () => sendMessage(button.dataset.prompt));
});
